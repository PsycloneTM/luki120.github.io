To apply the SettingsButtons download SettingsButtonsUI from https://nahtedetihw.github.io/ and place the icons here in SettingsButtonsUI.theme folder located in Library/Themes.


The name of the icons here are for LDRestart, SafeMode and Respring. If you want them for any other of the actions please go to ETHN's GitHub and in the source-code of SettingsButtons look for the name of the one you want. Enjoy 😛